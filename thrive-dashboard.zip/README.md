# Thrive Car Dashboard

## 🚗 موقع دليل السيارات والأسعار

موقع متصل مباشرة بـ Google Sheets — أي تعديل في الشيت ينعكس أوتوماتيكي.

## 🚀 إزاي ترفعه على GitHub Pages

### الخطوة 1: اعمل repo على GitHub
1. ادخل [github.com](https://github.com) واعمل حساب (لو ممعكش)
2. اضغط الزر الأخضر **New** → سمّي الـ repo `thrive-cars`
3. اختار **Public** → اضغط **Create repository**

### الخطوة 2: ارفع الملفات
1. في صفحة الـ repo الجديد، اضغط **uploading an existing file**
2. اسحب ملف `index.html` ده وارفعه
3. اضغط **Commit changes**

### الخطوة 3: فعّل GitHub Pages
1. اروح على **Settings** (تاب فوق)
2. من الشمال اضغط **Pages**
3. في **Source** اختار **Deploy from a branch**
4. اختار **Branch: main** و **Folder: / (root)**
5. اضغط **Save**

### الخطوة 4: استمتع!
- هتاخد لينك زي: `https://yourname.github.io/thrive-cars`
- الموقع هيشتغل فوراً!

## ⚠️ مهم: خلي الشيت Public

الموقع بيتصل بالشيت عن طريق Google Visualization API. لازم:
1. افتح Google Sheets
2. اضغط **Share**
3. اختار **Anyone with the link** → **Viewer**
4. اضغط **Done**

## 📱 المميزات
- ✅ متصل بالشيت أوتوماتيكي (كل 60 ثانية)
- ✅ يشتغل offline بنسخة احتياطية
- ✅ بحث وفلترة حية
- ✅ Responsive على الموبايل
